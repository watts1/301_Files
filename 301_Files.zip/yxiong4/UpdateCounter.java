package com.example.yxion.yxiong4_countbook;

/**
 * Created by yxion on 2017-10-01.
 */

import java.io.Serializable;
import java.text.DateFormat;
import java.util.Date;
import java.text.SimpleDateFormat;

// UpdateCounter class works to update the 5 data(name, current value, initial value, data and comment)
// in the specified counter. It can update the current value by one(increase or decrease), or reset the
// value to initial value, show the edit date, and changes the name and comment. It also override a string to
// return a string contain name/current value/data.


public class UpdateCounter implements Serializable {
    private String name;
    private Date date;
    private Integer current_value;
    private Integer  initial_value;
    private String comment;


    public UpdateCounter(String name,Integer initial_value,String comment){
        this.name = name;
        this.initial_value = initial_value;
        this.current_value = 0;
        this.comment = comment;
        this.date = new Date();
    }
    public UpdateCounter(String name, Integer initial_value){
        this(name,initial_value,"");
    }
    // get name from counter
    public String getName(){
        return this.name;
    }
    // get date from counter
    public String getDate(){
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        String dateString = df.format(date);
        return dateString;
    }
    //get initial value from counter
    public Integer getInitialValue(){
        return  initial_value;
    }
    //get current value from counter
    public Integer getCurrentValue(){
        return  current_value;
    }
    //get comment from counter
    public String getText(){
        return comment;
    }
    // increase current value by one
    public void increaseValue(){
        this.current_value += 1;
        return;
    }
    //decrease current value by one
    public void decreaseValue(){
        this.current_value -= 1;
        if (this.current_value >=0){
            return;
        }else{this.current_value = 0; return;}
    }
    // reset value to initial
    public void resetValue(){
        this.current_value = initial_value;
        return;
    }
    //update name and date()
    public void updateName(String name){
        this.date = new Date();
        this.name = name;
        return;
    }
    //update initial value and date()
    public void updateValue(Integer initial_value){
        this.date = new Date();
        this.initial_value = initial_value;
        return;
    }
    //update current value and date()
    public void updateCurrent(Integer value){
        this.date = new Date();
        this.current_value = value;
        return;
    }
    //update comment and date()
    public void updateComment(String comment){
        this.date = new Date();
        this.comment = comment;
        return;
    }
    @Override
    public String toString(){
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        String dateString = df.format(date);
        return "Name: "+name +" | Value: "+ Integer.toString(current_value) +" | Date: "+ dateString;
    }
}
