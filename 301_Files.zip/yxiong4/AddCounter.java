package com.example.yxion.yxiong4_countbook;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

// AddCounter activity called by MainActivity, allows the user to create a new counter by
// entering 3 initial values(name,initial value and comment). If users save the counter
// information by clicking save button, then AddCounter activity send the data back to
// MainActivity to create a new counter.


public class AddCounter extends AppCompatActivity {
    private static final String FILENAME = "file.sav";
    private static UpdateCounter update;
    private String name;
    private Integer value;
    private String text;
    private EditText addName;
    private EditText addValue;
    private EditText addText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_counter);
        addName = (EditText) findViewById(R.id.addName);
        addValue = (EditText) findViewById(R.id.addValue);
        addText = (EditText) findViewById(R.id.addComment);
        Button addButton = (Button) findViewById(R.id.saveButton);

        addButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                setResult(RESULT_OK);
                Intent resultIntent = new Intent();
                //handle exceptions.
                try {
                    name = addName.getText().toString().replaceAll("^\\s+", "");
                }catch (Exception e) {
                    name = "";
                }
                try {
                    value = Integer.parseInt(addValue.getText().toString());
                }catch (Exception e) {
                    value = -1;
                }
                text = addText.getText().toString();

                update = new UpdateCounter(name, value, text);
                Bundle result = new Bundle();
                result.putSerializable("count_here", update);
                resultIntent.putExtra("result",result);
                if (name ==""||value == -1 ){
                    setResult(-12,resultIntent);
                }else{
                    setResult(RESULT_OK,resultIntent);

                }

                finish();
            }
        });
    }
}
