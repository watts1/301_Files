// Cooperates with wyang2, gets help from other two group members.
// Created by Yuhang Xiong
// Last modified: 10/2/2017

package com.example.yxion.yxiong4_countbook;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.lang.reflect.Type;
import java.util.ArrayList;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

// MainActivity is the main class of this function, and it can call addCounter class
// for user to add a new counter, or it can call infoCounter class for user to check
// and edit the information in counter.
// It uses listView to build the counter list, uses ListAdapter to see counter information,
// uses ArrayList to contain counter lists, uses gson to save and load the file,
// uses pos for system to check the position users clicks.



public class MainActivity extends AppCompatActivity {
    private static final String FILENAME = "file.sav";
    private ListView counterView;
    private ArrayAdapter<UpdateCounter> adapter;
    private ArrayList<UpdateCounter> counterList;
    private TextView totalNumber;
    private int pos;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button addButton = (Button) findViewById(R.id.button);
        counterList = new ArrayList<UpdateCounter>();
        counterView = (ListView) findViewById(R.id.listView);
        totalNumber = (TextView) findViewById(R.id.total);
        loadFromFile();
        totalNumber.setText("Total Number of Counter: "+Integer.toString(counterList.size()));

        addButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                Intent addIntent = new Intent(MainActivity.this,AddCounter.class);
                startActivityForResult(addIntent,1);

            }
        });
        counterView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                pos = position;
                UpdateCounter chosenCount = (UpdateCounter) adapter.getItem(position);
                Intent infoIntent = new Intent(MainActivity.this,infoCounter.class);
                Bundle info = new Bundle();
                info.putSerializable("info_here",chosenCount);
                infoIntent.putExtra("info",info);
                startActivityForResult(infoIntent,2);
            }
        });
    }
    protected void onStart() {
        // TODO Auto-generated method stub
        super.onStart();
        adapter = new ArrayAdapter<UpdateCounter>(this, R.layout.item_list, counterList);
        counterView.setAdapter(adapter);
    }

    // get results from another activity
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        if(requestCode == 1) {
            if (resultCode == RESULT_OK) {
                Context context = getApplicationContext();
                CharSequence text = "add a count....";
                int duration = Toast.LENGTH_SHORT;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
                UpdateCounter oneCount = (UpdateCounter) data.getBundleExtra("result").getSerializable("count_here");
                counterList.add(oneCount);
                saveInFile();
                totalNumber.setText("The Toal Number of Counter: " + Integer.toString(counterList.size()));
                adapter.notifyDataSetChanged();
            }else if(resultCode == -12){
                Context context = getApplicationContext();
                CharSequence text = "user input is error please add again....";
                int duration = Toast.LENGTH_SHORT;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
            }
        }
        else if(requestCode == 2){
            if(resultCode == RESULT_OK) {
                Context context = getApplicationContext();
                CharSequence text = "Updating the counter....";
                int duration = Toast.LENGTH_SHORT;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
                UpdateCounter updatedCount = (UpdateCounter) data.getBundleExtra("update").getSerializable("update_here");
                counterList.set(pos, updatedCount);
                saveInFile();
                adapter.notifyDataSetChanged();
            }else if(resultCode == -11){

                Context context = getApplicationContext();
                CharSequence text = "Deleting the counter....";
                int duration = Toast.LENGTH_SHORT;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
                counterList.remove(pos);
                saveInFile();
                totalNumber.setText("Total Number of Counter: "+Integer.toString(counterList.size()));
                adapter.notifyDataSetChanged();
            }
        }
    };
    //load data
    private void loadFromFile() {
        try {
            FileInputStream fis = openFileInput(FILENAME);
            BufferedReader in = new BufferedReader(new InputStreamReader(fis));
            Gson gson = new Gson();
            Type listType = new TypeToken<ArrayList<UpdateCounter>>() {
            }.getType();
            counterList = gson.fromJson(in, listType);

        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            counterList = new ArrayList<UpdateCounter>();
        }
    }
    //save data
    private void saveInFile() {
        try {
            FileOutputStream fos = openFileOutput(FILENAME,
                    Context.MODE_PRIVATE);

            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(fos));
            Gson gson = new Gson();
            gson.toJson(counterList, out);
            out.flush();
            fos.close();
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            throw new RuntimeException();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            throw new RuntimeException();
        }
    }

}

