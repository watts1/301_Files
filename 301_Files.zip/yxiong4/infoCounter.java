package com.example.yxion.yxiong4_countbook;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

// infoCounter activity shows the information user saves in the counter, user clicks in the counter
// in the ListView, then enters to counter. In this activity, users can add or decrease current value
// by one each time througn clicking "increase" or "decrease", or delete the whole counter by click "delete",
// or click the reset button to reset the current value to initial value. User also can press save button
// to back to the menu.


public class infoCounter extends AppCompatActivity {
    private static final String FILENAME = "file.sav";
    private static UpdateCounter thisCount;
    private EditText EditCurrent;
    private TextView EditDate;
    private EditText EditName;
    private EditText EditInitial;
    private EditText EditComment;
    private String name;
    private Integer initial;
    private String comment;
    private Integer current;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info_counter);

        Button increase = (Button) findViewById(R.id.increase);
        Button decrease = (Button) findViewById(R.id.decrease);
        Button delete = (Button) findViewById(R.id.delete);
        Button reset = (Button) findViewById(R.id.reset);
        Button update = (Button) findViewById(R.id.save);
        EditName = (EditText) findViewById(R.id.editName);
        EditInitial = (EditText) findViewById(R.id.editInitial);
        EditComment = (EditText) findViewById(R.id.editComment);
        EditCurrent = (EditText) findViewById(R.id.editCurrent);
        EditDate = (TextView) findViewById(R.id.Date);

        try{
            thisCount = (UpdateCounter) getIntent().getBundleExtra("info").getSerializable("info_here");
        }catch (Exception e){
            thisCount = new UpdateCounter("",0);
        }

        EditName.setText(thisCount.getName());
        EditInitial.setHint("Initial Value: "+Integer.toString(thisCount.getInitialValue()));
        EditComment.setText(thisCount.getText());
        EditDate.setText("Date: "+thisCount.getDate());
        EditCurrent.setHint("Current Value: "+Integer.toString(thisCount.getCurrentValue()));

        increase.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                thisCount.increaseValue();
                EditCurrent.setText("Current Value: "+Integer.toString(thisCount.getCurrentValue()));
            }
        });

        decrease.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                thisCount.decreaseValue();
                EditCurrent.setText("Current Value: "+Integer.toString(thisCount.getCurrentValue()));
            }
        });

        reset.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                thisCount.resetValue();
                EditCurrent.setText("Current Value: "+Integer.toString(thisCount.getCurrentValue()));
            }
        });

        //handle exceptions.
        update.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                try {
                    name = EditName.getText().toString().replaceAll("^\\s+", "");
                    if (name ==""){
                        name = thisCount.getName();
                    }else {thisCount.updateName(name);}
                }catch (Exception e) {
                    name = thisCount.getName();
                }
                try {
                    initial = Integer.parseInt(EditInitial.getText().toString());
                    thisCount.updateValue(initial);
                }catch (Exception e) {
                    initial = thisCount.getInitialValue();
                }
                try{
                    comment = EditComment.getText().toString();
                    thisCount.updateComment(comment);
                }catch (Exception e){

                    comment = thisCount.getText();
                }

                try {
                    current = Integer.parseInt(EditCurrent.getText().toString());
                    thisCount.updateCurrent(current);
                }catch (Exception e) {
                    current = thisCount.getCurrentValue();
                }

                Intent updateIntent = new Intent();
                Bundle result = new Bundle();
                result.putSerializable("update_here",thisCount);
                updateIntent.putExtra("update",result);;
                setResult(RESULT_OK,updateIntent);
                finish();
            }
        });
        delete.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                Intent deleteIntent = new Intent();
                setResult(-11,deleteIntent);
                finish();
            }
        });
    }
}

